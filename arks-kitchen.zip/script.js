const translations = {
    en: {
        home: "Home",
        about: "About",
        recipes: "Recipes",
        welcome: "Welcome to Ark's Kitchen",
        intro: "Delicious recipes, cooking videos, and food photography.",
        "about-title": "About",
        "about-text": "Ark's Kitchen is a place where taste meets creativity. Explore recipes, watch cooking videos, and get inspired.",
        "recipes-title": "Recipes",
        "recipes-text": "Soon you will see our best recipes here!"
    },
    tr: {
        home: "Ana Sayfa",
        about: "Hakkında",
        recipes: "Tarifler",
        welcome: "Ark'ın Mutfağına Hoşgeldiniz",
        intro: "Lezzetli tarifler, yemek videoları ve fotoğraflar.",
        "about-title": "Hakkında",
        "about-text": "Ark'ın Mutfağı lezzetin yaratıcılıkla buluştuğu yerdir. Tarifleri keşfet, yemek videoları izle ve ilham al.",
        "recipes-title": "Tarifler",
        "recipes-text": "Yakında en iyi tariflerimizi burada göreceksiniz!"
    },
    de: {
        home: "Startseite",
        about: "Über uns",
        recipes: "Rezepte",
        welcome: "Willkommen bei Ark's Kitchen",
        intro: "Köstliche Rezepte, Kochvideos und Food-Fotografie.",
        "about-title": "Über uns",
        "about-text": "Ark's Kitchen ist ein Ort, an dem Geschmack auf Kreativität trifft. Entdecke Rezepte, schaue Kochvideos und lass dich inspirieren.",
        "recipes-title": "Rezepte",
        "recipes-text": "Bald findest du hier unsere besten Rezepte!"
    }
};

function setLanguage(lang) {
    document.querySelectorAll("[data-lang]").forEach(el => {
        const key = el.getAttribute("data-lang");
        el.textContent = translations[lang][key];
    });
}
